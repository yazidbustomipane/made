package com.dev.yazid.moviesubmission.onclick;

import android.view.View;

interface OnItemClickCallback {
    void onItemClicked(View view, int position);
}
